import UIKit

func calc(inputOne: Int, inputTwo: Int) -> Int {
    return inputOne + inputTwo
}
print(calc(inputOne: 3, inputTwo: 4))
print(calc(inputOne: 45, inputTwo: 56))
